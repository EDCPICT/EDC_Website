Animated Intro Section
=========

A collection of fancy text effects, to animate the tagline and action buttons of your website intro section.

[Article on CodyHouse](http://codyhouse.co/gem/animated-intro-section/)

[Demo](https://codyhouse.co/demo/animated-intro-section/index.html)

Video: [Mazwai](http://mazwai.com/#/)
 
[Terms](http://codyhouse.co/terms/)
